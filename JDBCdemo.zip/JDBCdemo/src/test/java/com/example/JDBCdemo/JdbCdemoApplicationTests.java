package com.example.JDBCdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JdbCdemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
